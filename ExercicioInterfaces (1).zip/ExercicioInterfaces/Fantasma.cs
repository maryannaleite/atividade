﻿namespace ExercicioInterfaces
{
    internal class Fantasma : IPairador
    {
        public void decolar() { Console.WriteLine("Fantasma saiu do chão: boooooo..."); }
        public void pairar() { Console.WriteLine("Fantasma está ali parado... no ar..."); }
        public void pousar() { Console.WriteLine("Fantasma pisou no chão... ele tem pés?"); }
        public void voar() { Console.WriteLine("Fantasma passou voando: uuuuuhhhhh..."); }
    }
}
