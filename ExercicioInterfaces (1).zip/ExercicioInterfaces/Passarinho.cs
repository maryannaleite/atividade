﻿namespace ExercicioInterfaces
{
    internal class Passarinho : IVoador, ISerVivo
    {
        public void decolar() { Console.WriteLine("O passarinho está Decolando: Piu piu piiiiiiiu!"); }
        public void pousar() { Console.WriteLine("O passarinho está Pousando: Piu!"); }
        public void voar() { Console.WriteLine("O passarinho está voando: Flap flap flap!"); }

        public void comer() { Console.WriteLine("Opa, formiga, adoro!"); }
        public void crescer() { Console.WriteLine("Até alcançar o céu!"); }
        public void dormir() { Console.WriteLine("Nem que seja pendurado..."); }
        public void morrer() { Console.WriteLine("Aquilo alí é uma cobra?"); }
        public void reproduzir() { Console.WriteLine("Eu tinha certeza que só tinha um ovo aqui quando eu saí..."); }


    }
}
