﻿namespace ExercicioInterfaces
{
    public interface IPairador:IVoador
    {
        public void pairar();
    }
}
