﻿namespace ExercicioInterfaces
{
    public class Helicoptero : IPairador, IMaquina
    {
        public void decolar() { Console.WriteLine("Helicoptero está decolando: tectectectectectec..."); }
        public void pairar() { Console.WriteLine("Helicoptero está pairando: vuvuvuvuvuvuvuvuvuvuvu..."); }
        public void pousar() { Console.WriteLine("Helicoptero está pousando: tutututututututututu..."); }
        public void voar() { Console.WriteLine("Helicptero está voando: vvrrrrrrrrrrorororororo"); }

        public void desligar() { Console.WriteLine("helicoptero off"); }
        public void emitirAlerta() { Console.WriteLine("calma, você é um profissinal preparado, eu to aqui..."); }
        public void ligar() { Console.WriteLine("Helicoptero on"); }
    }
}
