﻿// See https://aka.ms/new-console-template for more information
using ExercicioInterfaces;

Console.WriteLine("Hello, World!");

List<object> meusObjetos =  new List<object>();

meusObjetos.Add(new Passarinho());
meusObjetos.Add(new Aviao());
meusObjetos.Add(new SuperHomem());
meusObjetos.Add(new Fantasma());
meusObjetos.Add(new Helicoptero());
meusObjetos.Add(new BeijaFlor());
meusObjetos.Add(new Ovni());

Console.WriteLine("Listando os objetos e chamando seus métodos... baseado nas interfaces que eles implementam...");
foreach (object o in meusObjetos) 
{
    Console.WriteLine("------------------------------------------------------------");
    Console.WriteLine("O tipo do objeto é: " + o.GetType());
    if (o is IVoador) 
    {
        Console.WriteLine("O objeto é voador...");
        (o as IVoador).decolar();
        (o as IVoador).voar();
        (o as IVoador).pousar();
    }
    if (o is IPairador) 
    {
        Console.WriteLine("O objeto é pairador...");
        (o as IPairador).pairar();
    }
    if (o is ISerVivo) { (o as ISerVivo).crescer();
        Console.WriteLine("O objeto é um ser vivo...");
        (o as ISerVivo).comer();
        (o as ISerVivo).dormir();
        (o as ISerVivo).morrer();
    }
    if (o is IMaquina) 
    {
        Console.WriteLine("O objeto é uma maquina...");
        (o as IMaquina).ligar();
        (o as IMaquina).emitirAlerta();
        (o as IMaquina).desligar();
    }
    Console.WriteLine("------------------------------------------------------------");
}