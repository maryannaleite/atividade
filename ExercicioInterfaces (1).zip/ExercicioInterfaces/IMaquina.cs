﻿namespace ExercicioInterfaces
{
    public interface IMaquina
    {
        public void ligar();
        public void desligar();
        public void emitirAlerta();
    }
}
