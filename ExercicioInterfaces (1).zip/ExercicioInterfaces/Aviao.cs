﻿namespace ExercicioInterfaces
{
    public class Aviao : IVoador,IMaquina
    {
        public void decolar() { Console.WriteLine("O avião está decolando: ueeeeeennnnnnnn"); }
        public void pousar() { Console.WriteLine("O avião está pousando: tsssssss"); }
        public void voar() { Console.WriteLine("O avião está voando: uooooooooooonnnnn"); }

        public void desligar() { Console.WriteLine("avião off"); }
        public void emitirAlerta() { Console.WriteLine("pior que um motor pegando fogo são dois motores pegando fogo..."); }
        public void ligar() { Console.WriteLine("avião on"); }
    }
}
