﻿namespace ExercicioInterfaces
{
    internal class SuperHomem : IPairador, ISerVivo
    {
        public void decolar() { Console.WriteLine("Para o alto e avante!"); }
        public void pairar() { Console.WriteLine("Alguem precisa do superman, em algum lugar..."); }
        public void pousar() { Console.WriteLine("Está tudo bem agora, eu estou aqui..."); }
        public void voar() { Console.WriteLine("Whooosh"); }

        public void comer() { Console.WriteLine("Gosto de cachorro quente!"); }
        public void crescer() { Console.WriteLine("Ficou um homão!"); }
        public void dormir() { Console.WriteLine("Porque o peito é de aço mas a mente não..."); }
        public void morrer() { Console.WriteLine("Essa coisa verde é o que eu penso que é?"); }
        public void reproduzir() { Console.WriteLine("Vou chamar ele de Jhonatan..."); }
    }
}
