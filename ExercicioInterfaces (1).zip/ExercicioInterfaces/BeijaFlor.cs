﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioInterfaces
{
    internal class BeijaFlor : Passarinho, IPairador
    {
        public void pairar()
        {
            Console.WriteLine("Esse passarinho é capaz de pairar batendo as asas bem rápido flapflapflapflapflapflapflap....");
        }
    }
}
