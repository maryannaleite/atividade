﻿namespace ExercicioInterfaces
{
    public class Ovni : IPairador,IMaquina
    {
        public void decolar() { Console.WriteLine("Ovni está decolando: wonwonwonwonwonwonwonwon"); }
        public void pairar() { Console.WriteLine("Ovni está pairando: shhhhhhhhhhhh!"); }
        public void pousar() { Console.WriteLine("Ovni esta pousando: boooom!!! (Alienigena comprou o brevê)"); }
        public void voar() { Console.WriteLine("Ovni está voando: woosh!!!"); }

        public void desligar() { Console.WriteLine("se não parar de piscar atirem nele..."); }
        public void emitirAlerta() { Console.WriteLine("sabia que aquilo não era um portacopos..."); }
        public void ligar() { Console.WriteLine("tem certeza que consegue pilotar essa coisa?"); }
    }
}
