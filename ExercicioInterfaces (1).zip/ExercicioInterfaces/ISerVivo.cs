﻿namespace ExercicioInterfaces
{
    public interface ISerVivo
    {
        public void comer();
        public void dormir();
        public void crescer();
        public void reproduzir();
        public void morrer();
    }
}
