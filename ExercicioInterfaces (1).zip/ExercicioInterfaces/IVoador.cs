﻿namespace ExercicioInterfaces
{
    public interface IVoador
    {
        public void decolar();
        public void voar();
        public void pousar();
    }
}
